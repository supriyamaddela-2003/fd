#pragma once

struct ef_param_t {
    uint8_t val_type_size;
    uint8_t edge_type_size;
    uint8_t fwd_type_size;
    uint8_t degree_type_size;
    uint8_t chunk_align_size;
    uint8_t chunk_offset_size;
};
